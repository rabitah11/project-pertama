<?php
$angka = $_POST['angka'];

for ($i = 1; $i <= $angka; $i++) {
    echo $i . " ";
}