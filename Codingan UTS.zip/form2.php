<form method="POST" action="form2-proses.php">
    <label>angka</label>
    <input type="text" name="angka"/>
    <button type="submit">submit</button>
</form>
