<form method="POST" action="form7_proses.php">
    <label>angka</label>
    <input type="text" name="angka"/>
    <button type="submit">submit</button>
</form>