<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas 12</title>
</head>
<body>
    <form action="form12_proses.php" method="post">
        <label for="angka">Masukkan Angka (pisahkan dengan koma):</label>
        <input type="text" id="angka" name="angka"><br>
        <input type="submit" value="Hitung Total">
    </form>
</body>
</html>
