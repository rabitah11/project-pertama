<form method="POST" action="form3_proses.php">
    <label>tahun</label>
    <input type="text" name="tahun"/>
    <button type="submit">submit</button>
</form>
