<?php
$angka = 7;

if ($angka % 2 == 0) {
    echo "Angka genap";
} else {
    echo "Angka ganjil";
}