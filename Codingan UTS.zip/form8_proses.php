<?php
$num = 2;

while ($num <= 10) {
    echo $num . " ";
    $num += 2;
}