<form method="POST" action="form1-proses.php">
    <label>Angka</label>
    <input type="text" name="angka" />
    <button type="subhmit">Submit</button>
</form>

