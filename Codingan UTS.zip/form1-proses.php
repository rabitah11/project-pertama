<?php
$angka = $_POST['angka'];

if ($angka > 10) {
    echo "angka lebih besar dari 10";
} else {
    echo "angka tidak lebih besar dari 10";
}