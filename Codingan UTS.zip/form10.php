<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas 10</title>
</head>
<body>
    <form action="form10_proses.php" method="post">
        <label for="panjang">Panjang Deret Fibonacci:</label>
        <input type="number" id="panjang" name="panjang" min="1"><br>
        <input type="submit" value="Generate">
    </form>
</body>
</html>
