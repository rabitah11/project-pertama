<form method="POST" action="form5_proses.php">
    <label>kata</label>
    <input type="text" name="kata"/>
    <button type="submit">submit</button>
</form>
