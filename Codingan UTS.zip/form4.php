<form method="POST" action="form4_proses.php">
    <label>umur</label>
    <input type="text" name="umur"/>
    <button type="submit">submit</button>
</form>
