<form method="POST" action="form6_proses.php">
    <label>kode</label>
    <input type="text" name="kode_menu"/>
    <button type="submit">submit</button>
</form>
