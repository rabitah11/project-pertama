<form method="POST" action="form13_proses.php">
    <label>Angka</label>
    <input type="text" name="angka" />
    <button type="submit">submit</button>
</form>